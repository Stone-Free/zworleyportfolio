﻿using System;

namespace Lab6
{
    class Program
    {
        static void Main(string[] args)
        {
            double correct;
            double incorrect;
            double answer1;
            double answer2;
            double answer3;
            double answer4;
            double answer5;
            correct = 0;
            incorrect = 0;

            Console.WriteLine("Welcome to the test. There are five questions. Type the answer to each question. \n\r");

            Console.Write("5 + 5 = ");

            answer1 = Convert.ToInt32(Console.ReadLine());
            if (answer1 == 10)
            {
                correct++;
                Console.WriteLine("Correct. Next question.");
            }
            else
            {
                incorrect++;
                Console.WriteLine("Incorrect. Next question.");
            }

            Console.Write("40 - 10 = ");

            answer2 = Convert.ToInt32(Console.ReadLine());
            if (answer2 == 30)
            {
                correct++;
                Console.WriteLine("Correct. Next question.");
            }
            else
            {

                incorrect++;
                Console.WriteLine("Incorrect. Next question.");
            }

            Console.Write("20 * 3 = ");

            answer3 = Convert.ToInt32(Console.ReadLine());
            if (answer3 == 60)
            {
                correct++;
                Console.WriteLine("Correct. Next question.");
            }
            else
            {
                incorrect++;
                Console.WriteLine("Incorrect. Next question.");
            }

            Console.Write("15 / 5  = ");


            answer4 = Convert.ToInt32(Console.ReadLine());
            if (answer4 == 3)
            {
                correct++;
                Console.WriteLine("Correct. Next question.");
            }
            else
            {
                incorrect++;
                Console.WriteLine("Incorrect. Next question.");
            }

            Console.Write("20 + 15 - 10 / 5 = ");

            answer5 = Convert.ToInt32(Console.ReadLine());
            if (answer5 == 33)
            {
                correct++;
                Console.WriteLine("Correct. Next question.");
            }
            else
            {
                incorrect++;
                Console.WriteLine("Incorrect. Next question.");
            }

            Console.Write("You've completed the test. The amount of questions you've gotten correct is: ");
            Console.WriteLine(correct);
            Console.Write("The amount of questions you've gotten incorrect is: ");
            Console.WriteLine(incorrect);
            Console.Write("Press any key to leave the program.");
            Console.ReadKey();
        }
    }
}
