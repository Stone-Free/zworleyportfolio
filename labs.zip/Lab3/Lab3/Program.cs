﻿using System;

namespace Lab3
{
    class Program
    {
        static void Main(string[] args)
        {
            int x;
            int y;
            int answer;
            Console.WriteLine("Enter the first number to be added: ");
            x = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the second number to be added: ");
            y = Convert.ToInt32(Console.ReadLine());

            answer = x + y;

            Console.WriteLine("The sum of the two numbers is"); Console.WriteLine(answer);
            Console.ReadKey();

        }
    }
}
