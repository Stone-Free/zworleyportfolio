﻿using System;
using System.Reflection.Metadata.Ecma335;

namespace Lab12
{
    class Program
    {
        static Random rnd = new Random();
        static void Main(string[] args)
        {

            for (int i = 0; i < 5; i++)
            {
                Printroll();
            }
        }
            static int Roll()
        {
            int die1, die2, results;
            die1 = rnd.Next(1, 7);
            die2 = rnd.Next(1, 7);
            results = die1 + die2;
            return results;
        }
        static int Printroll()
        {
            Roll();
            Console.WriteLine(Roll());
            return Roll();
        }



    }
}
