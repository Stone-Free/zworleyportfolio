﻿using System;

namespace Lab11
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();

            int[] quiz = new int[5];
            int select;

            Console.WriteLine("Your quiz scores are below. Press a number from 1 to 5 to change that quiz score to a 10.");
            for (int i = 0; i < quiz.Length; i++)
            {
                quiz[i] = rnd.Next(11);
                Console.WriteLine("Quiz " + (i + 1) + ": " + quiz[i]);
            }

            select = Convert.ToInt32(Console.ReadLine());

            quiz[select - 1] = 10;

            Console.WriteLine("Your new scores are below.");
            for (int i = 0; i < quiz.Length; i++)
            {
                Console.WriteLine("Quiz " + (i+1) + ": " + quiz[i]);
            }

            Console.ReadLine();
        }
    }
}
