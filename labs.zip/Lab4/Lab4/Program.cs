﻿using System;

namespace Lab4
{
    class Program
    {
        static void Main(string[] args)
        {
            int l;
            int w;
            int perimeter;
            int area;
            Console.WriteLine("Enter the length of the rectangle: ");
            l = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the width of the rectangle: ");
            w = Convert.ToInt32(Console.ReadLine());

            perimeter = (l + w) * 2;
            area = l * w;

            Console.WriteLine("The perimeter of the rectangle is: ");
            Console.WriteLine(perimeter);
            Console.WriteLine("The area of the rectangle is: ");
            Console.WriteLine(area);
            Console.ReadKey();
        }
    }
}
