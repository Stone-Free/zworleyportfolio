﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IT1050_Lab15
{
    class Fraction
    {
        int numerator;
        int denominator;

        public Fraction(int numerator, int denominator)
        {
            this.numerator = numerator;
            this.denominator = denominator;
        }

        public void Multiply(int numerator, int denominator)
        {
            this.numerator = this.numerator * numerator;
            this.denominator = this.denominator * denominator;
        }

        public void Multiply(int wholeNumber)
        {
            this.numerator = this.numerator * wholeNumber;
        }

        public void Multiply(Fraction fraction)
        {
            this.numerator = this.numerator * fraction.numerator;
            this.denominator = this.denominator * fraction.denominator;
        }

        public void Divide(int numerator, int denominator)
        {
            this.numerator = this.numerator / denominator;
            this.denominator = this.denominator / numerator;
        }

        public void Divide(int wholeNumber)
        {
            this.numerator = this.numerator / wholeNumber;
        }

        public void Divide(Fraction fraction)
        {
            this.numerator = this.numerator / fraction.denominator;
            this.denominator = this.denominator / fraction.denominator;
        }

        public void Add(int numerator, int denominator)
        {
            int lcm;
            lcm = 12;
            int x;
            x = 0;
            x = 15 ;
            for (this.denominator = this.denominator; this.denominator < lcm; this.denominator++)
            {
            }
            for (this.denominator = this.denominator; denominator < lcm; denominator++)
            {
            }





        }

        public void Add(int wholeNumber)
        {

        }

        public void Add(Fraction fraction)
        {

        }

        public void Subtract(int numerator, int denominator)
        {

        }

        public void Subtract(int wholeNumber)
        {

        }

        public void Subtract(Fraction fraction)
        {

        }

        public string DisplayFraction()
        {

        }
    }
}
