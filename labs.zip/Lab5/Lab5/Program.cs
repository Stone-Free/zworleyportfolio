﻿using System;

namespace Lab5
{
    class Program
    {
        static void Main(string[] args)
        {
            double r;
            double c;
            double a;
            Console.WriteLine("Enter the radius of the circle: ");
            r = Convert.ToInt32(Console.ReadLine());

            c = (r * 2) * 3.1416;
            a = (r * r) * 3.1416;

            Console.WriteLine("The circumference of the circle is: ");
            Console.WriteLine(c);
            Console.WriteLine("The area of the circle is: ");
            Console.WriteLine(a);
            Console.ReadKey();
        }
    }
}
