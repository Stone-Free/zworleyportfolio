﻿using System;

namespace Lab12
{
    class Program
    {
        static Random rnd = new Random();
        static void Main(string[] args)
        {
            
            Console.WriteLine("Enter how many times you want to roll 1d6.");
            int rolls;
            rolls = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(Roll(rolls));
            Console.ReadLine();
            

        }
        static int Roll(int rolls)
        {
            int die, results;
            results = 0;
            for (int i = 0; i < rolls; i++)
            {
                die = rnd.Next(1, 7);
                results = die + results;
            }

            return results;
        }



    }
}

