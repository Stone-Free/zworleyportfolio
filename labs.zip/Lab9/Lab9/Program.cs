﻿using System;

namespace Lab9
{
    class Program
    {
        static void Main(string[] args)
        {

            for (int num = 1; num < 100; num++)
            {

                if (num % 3 != 0 && num % 7 != 0)
                {
                    Console.WriteLine(num);
                }
                else if (num % 3 == 0)
                {
                    Console.WriteLine("Hutt");
                }
                else if (num % 7 == 0)
                {
                    Console.WriteLine("Hike");
                }

                

            }
            Console.ReadLine();
        }
    }
}
