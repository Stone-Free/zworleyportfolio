﻿using System;

namespace Lab2
{
    class Program
    {
        static void Main(string[] args)
        {
            string person;
            string place;
            string item;
            string animal;
            string adjective;

            Console.Write("Enter a person and press enter: ");
            person = Console.ReadLine();

            Console.Write("Enter a place and press enter: ");
            place = Console.ReadLine();

            Console.Write("Enter the name of an item and press enter: ");
            item = Console.ReadLine();

            Console.Write("Enter an animal and press enter: ");
            animal = Console.ReadLine();

            Console.Write("Enter an adjective and press enter: ");
            adjective = Console.ReadLine();
            
            Console.Write("Sir ");
            Console.Write(person);
            Console.Write(" of ");
            Console.Write(place);
            Console.Write(", skillfully wielding a legendary ");
            Console.Write(item);
            Console.Write(", rode in on his mighty battle-");
            Console.Write(animal);
            Console.Write(" and slew the ");
            Console.Write(adjective);
            Console.Write(" dragon.");

            Console.ReadKey();


        }
    }
}
//
