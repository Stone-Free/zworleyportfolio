﻿using System;

namespace Lab7
{
    class Program
    {
        static void Main(string[] args)
        {
            int height;

            Console.WriteLine("Please enter your height in inches.");

            height = Convert.ToInt32(Console.ReadLine());

            if (height < 60 || height > 75)
            {
                Console.WriteLine("Your height is abnormal.");
            }

            else
            {
                Console.WriteLine("Your height is normal.");
            }

            Console.ReadKey();


            ;
        }
    }
}
