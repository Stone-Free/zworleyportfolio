﻿using System;

namespace Lab8
{
    class Program
    {
        static void Main(string[] args)
        {
            double goal;
            double ans;
            double guess;

            guess = 1;
            ans = 0;
            Random rnd = new Random();
            goal = rnd.Next(11);

            Console.Write("A number from 0 to 10 has been generated.  Try to guess it: ");
            ans = Convert.ToInt32(Console.ReadLine());
            while (ans != goal)
            {
                {
                    guess++;
                    Console.Write("You guessed incorrectly. You guessed too ");
                    if (ans < goal)
                    {
                        Console.Write("low. Guess again: ");
                        ans = Convert.ToInt32(Console.ReadLine());
                    }
                    else if (ans > goal)
                    {
                        Console.Write("high. Guess again: ");
                        ans = Convert.ToInt32(Console.ReadLine());
                    }
    ;
                }
            }

            Console.Write("You guessed the number. It took you ");
            Console.Write(guess);
            Console.Write(" tries to guess the right number.\nPress any key to continue.");
            Console.ReadKey();

        }
    }
}
