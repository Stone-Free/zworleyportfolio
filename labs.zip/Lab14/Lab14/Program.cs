﻿using System;

namespace Lab12
{
    class Program
    {
        static Random rnd = new Random();
        static void Main(string[] args)
        {
            int rolls, sides;
            Console.WriteLine("Enter how many times you want to roll a dice.");
            sides = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter how many sides each dice will have.");
            rolls = Convert.ToInt32(Console.ReadLine());
            Console.Write("The sum of all rolled dice is ");
            Console.Write(Roll(rolls, sides));
            Console.Write(".");
            Console.ReadLine();


        }
        static int Roll(int rolls, int sides)
        {
            int die, results;
            results = 0;
            for (int i = 0; i < rolls; i++)
            {
                die = rnd.Next(1, sides);
                results = die + results;
            }

            return results;
        }



    }
}


