﻿// See https://aka.ms/new-console-template for more information
using System;

namespace Lab10
{
    class Program
    {
        static void Main(string[] args)
        {
            int rolls;
            int sum;
            int die1, die2;
            double average;
            int t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12;
            int runtot;

            rolls = 0;
            t2 = 0;
            t3 = 0;
            t4 = 0;
            t5 = 0;
            t6 = 0;
            t7 = 0;
            t8 = 0;
            t9 = 0;
            t10 = 0;
            t11 = 0;
            t12 = 0;
            runtot = 0;
            average = 0;

            Random rnd = new Random();


            Console.WriteLine("How many times would you like to roll 2d6?");
            rolls = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < rolls; i++)
            {
                die1 = rnd.Next(7);
                die2 = rnd.Next(7);
                if (die1 + die2 == 2)
                {
                    ++t2;
                    runtot = runtot + die1 + die2;

                }
                else if (die1 + die2 == 3)
                {
                    ++t3;
                    runtot = runtot + die1 + die2;
                }
                else if (die1 + die2 == 4)
                {
                    ++t4;
                    runtot = runtot + die1 + die2;
                }
                else if (die1 + die2 == 5)
                {
                    ++t5;
                    runtot = runtot + die1 + die2;
                }
                else if (die1 + die2 == 6)
                {
                    ++t6;
                    runtot = runtot + die1 + die2;
                }
                else if (die1 + die2 == 7)
                {
                    ++t7;
                    runtot = runtot + die1 + die2;
                }
                else if (die1 + die2 == 8)
                {
                    ++t8;
                    runtot = runtot + die1 + die2;
                }
                else if (die1 + die2 == 9)
                {
                    ++t9;
                    runtot = runtot + die1 + die2;
                }
                else if (die1 + die2 == 10)
                {
                    ++t10;
                    runtot = runtot + die1 + die2;
                }
                else if (die1 + die2 == 11)
                {
                    ++t11;
                    runtot = runtot + die1 + die2;
                }
                else if (die1 + die2 == 12)
                {
                    ++t12;
                    runtot = runtot + die1 + die2;
                }



            }
            sum = t2 + t3 + t4 + t5 + t6 + t7 + t8 + t9 + t10 + t11 + t12;
            
            average = runtot / rolls;

            Console.WriteLine("The number of times each total hit is:");
            Console.Write("2: ");
            Console.WriteLine(t2);
            Console.Write("3: ");
            Console.WriteLine(t3);
            Console.Write("4: ");
            Console.WriteLine(t4);
            Console.Write("5: ");
            Console.WriteLine(t5);
            Console.Write("6: ");
            Console.WriteLine(t6);
            Console.Write("7: ");
            Console.WriteLine(t7);
            Console.Write("8: ");
            Console.WriteLine(t8);
            Console.Write("9: ");
            Console.WriteLine(t9);
            Console.Write("10: ");
            Console.WriteLine(t10);
            Console.Write("11: ");
            Console.WriteLine(t11);
            Console.Write("12: ");
            Console.WriteLine(t12);

            Console.Write("The average of all of your rolls is: ");
            Console.WriteLine(average);
            Console.ReadLine();













        }
    }
}
