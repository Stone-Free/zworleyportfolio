﻿using System;

namespace Lab1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("My name is Zayvion Worley. \r\n My programming experience is in HTML making character profiles for people and making a really bad game in Gamemaker Studio like two years ago. I also know a little bit of python and c++, but it's been a while since I used it.\r\nI became interested in computers and programming because using a computer comes naturally to me, to the point where I don't really own any game consoles. I just use my computer. \r\n From this class I expect to find out if programming is something I enjoy or am at least good at. Despite dabbling in programming a little through free tutorials online I don't think I really have a grasp on it as a whole.\r\nAfter Tri-C I plan on going to Baldwin Wallace for the Cybersecurity Analyst bachelor's degree. I think it's more important to find a job that makes a difference than to necessarily find something you love doing, and cybersecurity majors are definitely going to make an impact as more and more things become virtual.\r\n A dream goal I have is to own a successful cybersecurity company.");
            Console.ReadKey();
        }
    }
}